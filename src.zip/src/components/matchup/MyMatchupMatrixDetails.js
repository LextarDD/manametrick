// src/components/matchup/MyMatchupMatrixDetails.js
import React, { useMemo } from 'react';
import Modal from '../shared/Modal';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

const COLORS = { win: '#4ade80', loss: '#f87171', draw: '#3b82f6' };

const expandRoundToGames = (result, score) => {
  const s = score || (result === 'win' ? '2-0' : result === 'draw' ? '1-1' : '0-2');
  if (s === '2-0') return ['win', 'win'];
  if (s === '2-1') return ['win', 'win', 'loss'];
  if (s === '0-2') return ['loss', 'loss'];
  if (s === '1-2') return ['win', 'loss', 'loss'];
  if (s === '1-1') return ['win', 'loss'];
  if (result === 'win')  return ['win', 'win'];
  if (result === 'loss') return ['loss', 'loss'];
  return ['win', 'loss'];
};

const MyMatchupMatrixDetails = ({ user, playerArch, oppArch, games, onClose }) => {
  const stats = useMemo(() => {
    if (!games || !playerArch || !oppArch) return null;

    const relevantRounds = games.filter(g =>
      (g.archetype === playerArch && g.opponent_archetype === oppArch) ||
      (g.archetype === oppArch    && g.opponent_archetype === playerArch)
    );

    let wins = 0, losses = 0, draws = 0;

    for (const round of relevantRounds) {
      const isCanonical = round.archetype === playerArch;
      if (round.result === 'draw' || round.score === '1-1') {
        draws++;
        continue;
      }
      const individualResults = expandRoundToGames(round.result, round.score);
      for (const indResult of individualResults) {
        const normalizedResult = isCanonical ? indResult : (indResult === 'win' ? 'loss' : 'win');
        if (normalizedResult === 'win') wins++;
        else losses++;
      }
    }

    const total = wins + losses + draws;
    const decided = wins + losses;
    const winrate = decided > 0 ? Math.round((wins / decided) * 1000) / 10 : null;

    return { wins, losses, draws, total, winrate };
  }, [games, playerArch, oppArch]);

  if (!stats) return null;

  const { wins, losses, draws, total, winrate } = stats;
  const decided = wins + losses;

  const pieData = total > 0
    ? [
        { name: 'Victorias', value: wins },
        { name: 'Derrotas',  value: losses },
        ...(draws > 0 ? [{ name: 'Empates', value: draws }] : []),
      ]
    : [{ name: 'Sin datos', value: 1 }];

  const pieColors = total > 0
    ? [COLORS.win, COLORS.loss, COLORS.draw]
    : ['#1e293b'];

  const statPills = [
    { label: 'Winrate',   value: winrate !== null ? `${winrate}%` : '—', color: winrate !== null ? (winrate >= 50 ? '#4ade80' : '#f87171') : '#64748b' },
    { label: 'Victorias', value: wins,   color: '#4ade80' },
    { label: 'Derrotas',  value: losses, color: '#f87171' },
    ...(draws > 0 ? [{ label: 'Empates', value: draws, color: '#3b82f6' }] : []),
    { label: 'Partidas',  value: total,  color: '#94a3b8' },
  ];

  const barRows = [
    { label: 'Victorias', value: wins,   color: COLORS.win,  pct: decided > 0 ? (wins   / decided * 100) : 0 },
    { label: 'Derrotas',  value: losses, color: COLORS.loss, pct: decided > 0 ? (losses / decided * 100) : 0 },
    ...(draws > 0 ? [{ label: 'Empates', value: draws, color: COLORS.draw, pct: total > 0 ? (draws / total * 100) : 0 }] : []),
  ];

  const winrateColor = winrate !== null ? (winrate >= 50 ? '#4ade80' : '#f87171') : '#64748b';
  const winrateLabel = winrate !== null ? `${winrate}%` : '—';

  return (
    <Modal onClose={onClose}>
      <div style={{ fontFamily: "'Crimson Pro', Georgia, serif", minWidth: '320px', maxWidth: '520px', width: '100%' }}>

        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
          borderRadius: '12px 12px 0 0',
          padding: '24px 28px 20px',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundImage: 'radial-gradient(circle at 80% 20%, rgba(99,102,241,0.15) 0%, transparent 60%)', pointerEvents: 'none' }} />
          <div style={{ fontSize: '0.7rem', color: '#818cf8', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '4px' }}>
            Matchup combinado
          </div>
          <h2 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 700, color: '#f1f5f9' }}>
            {playerArch} <span style={{ color: '#475569' }}>vs</span> {oppArch}
          </h2>
        </div>

        {/* Body */}
        <div style={{ padding: '24px 28px', background: '#0f172a', borderRadius: '0 0 12px 12px' }}>
          {total === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: '#475569', fontSize: '0.95rem', fontStyle: 'italic' }}>
              No hay partidas registradas entre {playerArch} y {oppArch}.
            </div>
          ) : (
            <>
              {/* Stat pills */}
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginBottom: '20px' }}>
                {statPills.map(({ label, value, color }) => (
                  <div key={label} style={{ background: '#1e293b', borderRadius: '10px', padding: '12px 14px', flex: '1', minWidth: '64px', textAlign: 'center', border: '1px solid #334155' }}>
                    <div style={{ fontSize: '1.35rem', fontWeight: 700, color }}>{value}</div>
                    <div style={{ fontSize: '0.6rem', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: '2px' }}>{label}</div>
                  </div>
                ))}
              </div>

              {/* Chart area */}
              <div style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: '10px', padding: '16px 20px', marginBottom: '16px' }}>

                {/* Dona + label central via SVG overlay */}
                <div style={{ position: 'relative', height: '160px', marginBottom: '16px' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%" cy="50%"
                        innerRadius={44} outerRadius={66}
                        paddingAngle={total > 0 ? 3 : 0}
                        dataKey="value"
                        startAngle={90} endAngle={-270}
                        isAnimationActive={false}
                      >
                        {pieData.map((_, i) => (
                          <Cell key={i} fill={pieColors[i]} strokeWidth={0} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  {/* Label central superpuesto */}
                  <div style={{
                    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                    pointerEvents: 'none',
                  }}>
                    <span style={{ fontSize: '1.15rem', fontWeight: 700, color: winrateColor, lineHeight: 1.1 }}>
                      {winrateLabel}
                    </span>
                    <span style={{ fontSize: '0.6rem', color: '#64748b', letterSpacing: '0.05em', marginTop: '2px' }}>
                      winrate
                    </span>
                  </div>
                </div>

                {/* Barras horizontales */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '12px' }}>
                  {barRows.map(({ label, value, color, pct }) => (
                    <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{ fontSize: '0.75rem', color: '#64748b', width: '60px', textAlign: 'right', flexShrink: 0 }}>{label}</span>
                      <div style={{ flex: 1, height: '26px', background: 'rgba(255,255,255,0.04)', borderRadius: '5px', overflow: 'hidden' }}>
                        <div style={{
                          width: `${Math.max(pct, 0)}%`,
                          height: '100%',
                          background: color + '38',
                          borderRadius: '5px',
                          display: 'flex', alignItems: 'center', paddingLeft: '8px',
                          minWidth: pct > 0 ? '44px' : '0',
                        }}>
                          {pct > 0 && (
                            <span style={{ fontSize: '0.72rem', fontWeight: 700, color }}>{pct.toFixed(1)}%</span>
                          )}
                        </div>
                      </div>
                      <span style={{ fontSize: '0.72rem', color: '#475569', width: '16px', textAlign: 'right', flexShrink: 0 }}>{value}</span>
                    </div>
                  ))}
                </div>

                {/* Leyenda */}
                <div style={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
                  {barRows.map(({ label, color }) => (
                    <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: color, flexShrink: 0 }} />
                      <span style={{ fontSize: '0.78rem', color: '#94a3b8' }}>{label}</span>
                    </div>
                  ))}
                </div>

              </div>
            </>
          )}

          <button
            onClick={onClose}
            style={{ width: '100%', padding: '11px', background: 'transparent', border: '1px solid #334155', borderRadius: '8px', color: '#94a3b8', cursor: 'pointer', fontFamily: 'inherit', fontSize: '0.9rem', transition: 'all 0.2s' }}
            onMouseEnter={e => { e.target.style.background = '#1e293b'; e.target.style.color = '#f1f5f9'; }}
            onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.color = '#94a3b8'; }}
          >
            Cerrar
          </button>
        </div>

      </div>
    </Modal>
  );
};

export default MyMatchupMatrixDetails;